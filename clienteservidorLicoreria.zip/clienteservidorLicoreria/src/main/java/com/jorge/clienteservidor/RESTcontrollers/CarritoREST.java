package com.jorge.clienteservidor.RESTcontrollers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jorge.clienteservidor.servicios.ServicioCarrito;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("carritoREST/")
public class CarritoREST {
	
	@Autowired
	ServicioCarrito servicioCarrito;
	
	
	@RequestMapping("eliminar")
	public String eliminarProductoCarrito(@RequestParam("id") Long id,HttpServletRequest request) {
		long idUsuario= (long) request.getSession().getAttribute("usuario_id");
		servicioCarrito.quitarProductoCarrito(idUsuario,id);
		return "ok";
	}
	
	
	@RequestMapping("obtener")
	public List<Map<String,Object>> obtenerCarrito(HttpServletRequest request) {
		long idUsuario = (long) request.getSession().getAttribute("usuario_id");
		return servicioCarrito.obtenerProductosCarrito(idUsuario);
	}
	
	@RequestMapping("agregarProducto")
	public String agregarProducto(Integer id,Integer cantidad,HttpServletRequest request) {
		long idUsuario = (long) request.getSession().getAttribute("usuario_id");
		System.out.println("Ya tenemos todo lo necesario para agregar un producto al carrito");
		System.out.println("idUsuario: "+idUsuario+", idProducto: "+id+", cabtidad: "+cantidad );
		servicioCarrito.agregarProducto(idUsuario, id, cantidad);
		return "OK";
		
	}
	
	
}
