package com.jorge.clienteservidor.controllers.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.jorge.clienteservidor.modelo.Licor;
import com.jorge.clienteservidor.servicios.ServicioCategoria;
import com.jorge.clienteservidor.servicios.ServicioLicor;

import jakarta.validation.Valid;

@Controller
@RequestMapping("admin/")
public class LicoresController {

	@Autowired
	private ServicioLicor servicioLicor;
	
	@Autowired
	private ServicioCategoria servicioCategoria;

	@RequestMapping("guardarCambioLicor")
	public String guardarCambioLicor(@ModelAttribute("licorEditar") Licor licorEditar,BindingResult resultadoValidaciones, Model model ) {
		if(resultadoValidaciones.hasErrors()) {
			model.addAttribute("categorias",servicioCategoria.obtenerCategorias());
			return "admin/editarLicor";
		}
		servicioLicor.actualizarLicor(licorEditar);
		return obtenerLicores(model);
	}
	
	@RequestMapping("editarLicor")
	public String editarLicor(@RequestParam("id") Long id, Model model) {
		Licor licor = servicioLicor.obtenerLicorPorId(id);
		model.addAttribute("licorEditar",licor);
		model.addAttribute("categorias",servicioCategoria.obtenerCategorias());
		return "admin/editarLicor";
	}

	@RequestMapping("guardarLicor")
	public String guardarLicor(@ModelAttribute("nuevoLicor")  @Valid Licor nuevolicor,BindingResult resultadoValidaciones, Model model) {
		if(resultadoValidaciones.hasErrors()) {
			model.addAttribute("categorias",servicioCategoria.obtenerCategorias());
			return "admin/registrarLicor";
		}
		servicioLicor.registrarLicor(nuevolicor);
		return obtenerLicores(model);
	}

	@RequestMapping("registrarLicor")
	public String registrarLibro(Model model) {
		Licor licor = new Licor();
		licor.setPrecio(1);
		model.addAttribute("nuevoLicor", licor);
		model.addAttribute("categorias",servicioCategoria.obtenerCategorias());
		return "admin/registrarLicor";
	}

	@RequestMapping("obtenerLicores")
	public String obtenerLicores(Model model) {
		model.addAttribute("licores", servicioLicor.obtenerLicores());
		return "admin/licores";
	}

	@RequestMapping("borrarLicor")
	public String borrarLibro(@RequestParam("id") Long id, Model model) {
		servicioLicor.borrarLicor(id);
		return obtenerLicores(model);
	}
}
