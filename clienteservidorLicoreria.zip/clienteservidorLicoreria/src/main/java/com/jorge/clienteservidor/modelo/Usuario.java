package com.jorge.clienteservidor.modelo;

import java.util.ArrayList;
import java.util.List;

import com.jorge.clienteservidor.modelo.Carrito;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity(name = "usuario")
@Table(name = "usuario")
public class Usuario {

	private String nombre;
	private String pass;
	@Column(unique = true)
	private String email;
	private String pais;
	private int edad;
	@OneToMany(mappedBy = "usuario")
	private List<Carrito> productosCarrito = new ArrayList<Carrito>();
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	
	public Usuario() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Usuario(String nombre, String pass, String email, String pais, int edad) {
		super();
		this.nombre = nombre;
		this.pass = pass;
		this.email = email;
		this.pais = pais;
		this.edad = edad;
	}



	public Usuario(String nombre, String pass, String email, String pais, int edad, long id) {
		super();
		this.nombre = nombre;
		this.pass = pass;
		this.email = email;
		this.pais = pais;
		this.edad = edad;
		this.id = id;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getPass() {
		return pass;
	}


	public void setPass(String pass) {
		this.pass = pass;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPais() {
		return pais;
	}


	public void setPais(String pais) {
		this.pais = pais;
	}


	public int getEdad() {
		return edad;
	}


	public void setEdad(int edad) {
		this.edad = edad;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}



	public List<Carrito> getProductosCarrito() {
		return productosCarrito;
	}



	public void setProductosCarrito(List<Carrito> productosCarrito) {
		this.productosCarrito = productosCarrito;
	}

	
	
}
