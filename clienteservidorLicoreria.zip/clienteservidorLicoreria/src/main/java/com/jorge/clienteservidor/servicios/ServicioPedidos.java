package com.jorge.clienteservidor.servicios;

import java.util.List;

import com.jorge.clienteservidor.RESTcontrollers.datos.ResumenPedidio;
import com.jorge.clienteservidor.modelo.Pedido;

public interface ServicioPedidos {

	List<Pedido> obtenerPedidos();
	
	Pedido obtenerPedidoPorId(int idPedido);
	
	void actualizarPedido(int idPedido, String estado);
	
	void procesarPaso1(String nombre, String direccion, String provincia,String cp,String email,String tel, long idUsuario);

	ResumenPedidio procesarPaso2(String tarjeta, String numero, String titular, long idUsuario);

	void procesarPasoExtra(String fav, long idUsuario);
	
	void confirmarPedido(long idUsuario);


	
	
	
}
