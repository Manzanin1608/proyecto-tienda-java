package com.jorge.clienteservidor.controllers.loginAdmin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jorge.clienteservidor.controllers.admin.LicoresController;

import jakarta.servlet.http.HttpServletRequest;

//Controlador que se encarga de identificar a un admin
@Controller
public class loginAdminController {

	@Autowired
	private LicoresController licoressController;
	@Autowired
	private MessageSource messageSource;
	
	@RequestMapping("loginAdmin")
	public String loginAdmin(){
		return "admin/loginAdmin";
	}
	

	
	@RequestMapping("logoutAdmin")
	public String logoutAdmin(HttpServletRequest request) {
		String idiomaActual = messageSource.getMessage("idioma", null,LocaleContextHolder.getLocale());
		request.getSession().invalidate();
		return "tienda_"+idiomaActual;	
	}
	
}
