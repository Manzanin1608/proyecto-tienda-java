package com.jorge.clienteservidor.servicios;

import java.util.List;
import java.util.Map;

public interface ServicioCarrito {

	void agregarProducto(long idUsuario,long idProducto,int cantidad);
	
	List<Map<String,Object>> obtenerProductosCarrito(long idUsuario);

	void quitarProductoCarrito(long idUsuario, Long idLicor);
	
}
