package com.jorge.clienteservidor.serviciosJPAImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jorge.clienteservidor.constantesSQL.ConstantesSQL;
import com.jorge.clienteservidor.modelo.Categoria;
import com.jorge.clienteservidor.modelo.Licor;
import com.jorge.clienteservidor.servicios.ServicioLicor;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import jakarta.persistence.TupleElement;

@Service
@Transactional
public class ServicioLicoresImpl implements ServicioLicor{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public void registrarLicor(Licor licor) {
		try {
			licor.setImagenPortada(licor.getFoto().getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Categoria categoria = entityManager.find(Categoria.class, licor.getIdCategoria());
		//licor.setCategoria(categoria);
		entityManager.persist(licor);
		
	}

	@Override
	public List<Licor> obtenerLicores() {
		List<Licor> licores = entityManager.createQuery("SELECT l FROM licores as l").getResultList();
		return licores;
	}

	@Override
	public void borrarLicor(long id) {
		//createNativeQuery lanza sql, no confundir con createQuery
		entityManager.createNativeQuery("DELETE FROM carrito WHERE licor_id = :id").setParameter("id", id).executeUpdate();
		entityManager.createNativeQuery("DELETE FROM PRODUCTO_PEDIDO WHERE licor_id = :id").setParameter("id", id).executeUpdate();
		entityManager.createNativeQuery("DELETE FROM licores WHERE id = :id").setParameter("id", id).executeUpdate();
		
	}

	@Override
	public void actualizarLicor(Licor licor) {
		Licor licorBaseDeDatos = entityManager.find(Licor.class, licor.getId());
		licorBaseDeDatos.setAlcohol(licor.getAlcohol());
		licorBaseDeDatos.setNombre(licor.getNombre());
		licorBaseDeDatos.setMarca(licor.getMarca());
		licorBaseDeDatos.setPorcentaje(licor.getPorcentaje());
		licorBaseDeDatos.setPrecio(licor.getPrecio());
		licorBaseDeDatos.setPais_origen(licor.getPais_origen());
		licorBaseDeDatos.setDescripcion(licor.getDescripcion());
		if(licor.getFoto().getSize() > 0) {
			try {
				licorBaseDeDatos.setImagenPortada(licor.getFoto().getBytes());
			} catch (IOException e) {
				System.out.println("no se pudo procesar el archivo subido");
				e.printStackTrace();
			}
		}
		licorBaseDeDatos.setCategoria(entityManager.find(Categoria.class, licor.getIdCategoria()));
		
		entityManager.merge(licorBaseDeDatos);
		
	}

	@Override
	public Licor obtenerLicorPorId(long id) {
		return entityManager.find(Licor.class, id);
	}

	@Override
	public List<Map<String, Object>> obtenerLicoresParaFormarJson() {
		Query query = entityManager.createNativeQuery(ConstantesSQL.SQL_OBTENER_LICORES_PARA_JSON, Tuple.class);
		List<Tuple> tuples = query.getResultList();

		List<Map<String, Object>> resultado = new ArrayList<>();
		for (Tuple tuple : tuples) {
		    Map<String, Object> fila = new HashMap<>();
		    for (TupleElement<?> element : tuple.getElements()) {
		        fila.put(element.getAlias(), tuple.get(element));
		    }
		    resultado.add(fila);
		}
		return resultado;
	}

}
