function checkout_paso_3(json){
	let html = Mustache.render(plantilla_checkout_3, json)
		$("#licores_container").html(html)
		$("#aceptar_paso_3").click(function(){
			$.post("pedidosREST/paso3").done(function(res){
				if(res == "ok"){
					obtenerLicores()
				}
			})
		})
}

function checkout_paso_extra(){
	$("#licores_container").html(plantilla_checkout_extra)
	$("#aceptar_paso_3").submit(function(e){
		e.preventDefault()
		favorito = $("#licor_fav").val()
		$.post("pedidosREST/pasoExtra",{
			fav : favorito,
		}).done(function(res){
			//usar la plantilla de checout paso 3 y procesarla con el json recibido
			alert(res)
			if(res == "ok"){
				checkout_paso_2()
			}
		})
	})
}


function checkout_paso_2(){
	$("#licores_container").html(plantilla_checkout_2)
	$("#aceptar_paso_2").submit(function(e){
		e.preventDefault()
		tipo_tarjeta = $("#tipo_tarjeta").find(":selected").val()
		if(tipo_tarjeta == "0"){
			alert("selecciona un tipo de tarjeta")
			return
		}
		num_tarjeta = $("#numero_tarjeta").val()
		titular = $("#titular_tarjeta").val()
		$.post("pedidosREST/paso2",{
			tarjeta : tipo_tarjeta,
			numero : num_tarjeta,
			titular : titular
		}).done(function(res){
			//usar la plantilla de checout paso 3 y procesarla con el json recibido
			checkout_paso_3(res)
		})
	})
}

function checkout_paso_1(){
	nombre = $("#campo_nombre").val()
	direccion = $("#campo_direccion").val()
	provincia = $("#campo_provincia").val()
	cp = $("#campo_codigo_postal").val()
	tel = $("#campo_telefono").val()
	email = $("#campo_email").val
	$.post("pedidosREST/paso1",{
		nombre: nombre,
		direccion: direccion,
		provincia: provincia,
		cp: cp,
		tel: tel,
		email: email
	}).done(function(res){
		alert(res)
		if(res == "ok"){
			checkout_paso_extra()
		}
	})
}

function checkout_paso_0(){
	$("#licores_container").html(plantilla_checkout_1)
	$("#aceptar_paso_1").submit(
		function(e){
			e.preventDefault()
			checkout_paso_1()	
		})
}




function mostrarCarrito(){
	//$("#contenedor").html(plantilla_carrito)
	if (nombre_login == "") {
		alert("tienes que identificarte para comprar productos")
	} else {
		$.get("carritoREST/obtener", function(r){
			if (r.length == 0) {
				alert("aun no has agregado nada al carrito")	
			}else{
				let html = Mustache.render(plantilla_carrito,r)
				$("#licores_container").html(html)
				//decir que hay que hacer cuando se haga click
				$("#realizar_pedido").click(checkout_paso_0)
				//en el enlace de borrar producto 
				$(".enlace-borrar-producto-carrito").click(function(){
					var idLicor = $(this).attr("id-licor")
					console.log("mandar el id de licor: "+idLicor+" a carritoREST para que lo borre del carrito")
					$.post("carritoREST/eliminar",{
						id:idLicor
					}).done(function(res){
						alert(res)
						if(res=="ok"){
							mostrarCarrito()
						}
					})//end done
				})//end borrar producto-carrito
			}//end else
		})//end get
	}
	
}

function changeQty(id, delta) {
    const input = document.getElementById('qty-' + id);
    let current = parseInt(input.value);
    current = isNaN(current) ? 1 : current + delta;
    if (current < 1) current = 1; 
    input.value = current;
}

function comprar_producto() {
	if (nombre_login == "") {
		alert("tienes que identificarte para comprar productos")
	} else {
		var id_producto = $(this).attr("id-producto")
		var cantidadProducto = $("#qty-" + id_producto).val();
		console.log("añadir producto de id: " + id_producto + " al carrito")
		$.post("carritoREST/agregarProducto",{
			id: id_producto,
			cantidad: cantidadProducto
		}).done(function(res){
			alert(res)	
		})
	}
}

function obtenerLicores() {
	$.get("LicoresREST/obtener", function(r) {
		//codigo a ejecutar cuando reciba la respuesta del recurso indicado
		//alert("recibido: "+ r)
		var licores = r
		console.log(licores)
		var html = Mustache.render(plantilla_licores, {
			array_licores: licores
		})

		$("#licores_container").html(html)
		$('.cart-link').click(comprar_producto)
	})//end $.get
	$("#licores_container").html("Cargando....")
}//end obtenerLibros

function mostrarLogin() {
	$("#licores_container").html(plantilla_login)
	$('#form_login').submit(function(e) {
		e.preventDefault()
		var email = $('#email').val()
		var pass = $('#pass').val()
		$.post("UsuariosREST/login", {
			email: email,
			pass: pass
		}).done(function(res) {
			var parte1 = res.split(",")[0]
			var parte2 = res.split(",")[1]
			if (parte1 == "ok") {
				alert("Bienvenido " + parte2 + " ya puedes comprar")
				nombre_login = parte2
				$("#login_user").html("Hola " + parte2)
				obtenerLicores()
			} else {
				alert(res)
			}
		})//end done
	})//end submit
}//end mostrarLogin

function mostrarRegistro() {
	$("#licores_container").html(plantilla_registrar)
	//Vamos a interceptar el envio de formulario
	$('#form_Registro').submit(function(e) {
		e.preventDefault()
		//alert('se intenta enviar form')
		//recoger los datos del form y mandarselos a UsuariosRest
		var nombre = $("#nombre").val()
		var edad = $("#edad").val()
		var pais = $("#pais").val()
		var email = $("#email").val()
		var pass = $("#pass").val()
		$.post("UsuariosREST/registrar", {
			nombre: nombre,
			edad: edad,
			pais: pais,
			email: email,
			pass: pass
		}).done(function(res) {
			alert(res)
		})//end done
	})//end submit form
}//end mostrarLogin

$("#enlace_productos").click(obtenerLicores)
$("#enlace_identificacion").click(mostrarLogin)
$("#enlace_registrarme").click(mostrarRegistro)
$("#enlace_carrito").click(mostrarCarrito)